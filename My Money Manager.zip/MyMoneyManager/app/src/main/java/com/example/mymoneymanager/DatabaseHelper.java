package com.example.mymoneymanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MoneyManager.db";
    private static final int DATABASE_VERSION = 2;
    public static final String TABLE_NAME = "expenses";
    public static final String COL_ID = "ID";
    public static final String COL_NAME = "NAME";
    public static final String COL_AMOUNT = "AMOUNT";
    public static final String COL_CATEGORY = "CATEGORY";
    public static final String COL_DATE = "DATE";

    public static final String TABLE_SETTINGS = "settings";
    public static final String COL_ID_SETTINGS = "ID";
    public static final String COL_DARK_MODE = "DARK_MODE"; // 0 for light mode, 1 for dark mode

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create expenses table
        String createExpenseTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NAME + " TEXT, " +
                COL_AMOUNT + " REAL, " +
                COL_CATEGORY + " TEXT, " +
                COL_DATE + " TEXT)";
        db.execSQL(createExpenseTable);

        // Create settings table
        String createSettingsTable = "CREATE TABLE " + TABLE_SETTINGS + " (" +
                COL_ID_SETTINGS + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DARK_MODE + " INTEGER DEFAULT 0)";
        db.execSQL(createSettingsTable);

        // Insert default setting for dark mode
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DARK_MODE, 0);
        db.insert(TABLE_SETTINGS, null, contentValues);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // If upgrading to version 2, create the settings table if not already present
            String createSettingsTable = "CREATE TABLE IF NOT EXISTS " + TABLE_SETTINGS + " (" +
                    COL_ID_SETTINGS + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_DARK_MODE + " INTEGER DEFAULT 0)";
            db.execSQL(createSettingsTable);

            // Insert default setting for dark mode if not present
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_DARK_MODE, 0);
            db.insert(TABLE_SETTINGS, null, contentValues);
        }
    }

    // Insert a new expense
    public boolean insertExpense(String name, float amount, String category, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_AMOUNT, amount);
        contentValues.put(COL_CATEGORY, category);
        contentValues.put(COL_DATE, date);
        long result = db.insert(TABLE_NAME, null, contentValues);
        db.close();
        return result != -1;
    }

    // Retrieve all expenses
    public List<Expense> getAllExpenses() {
        return getExpenses(null, null, null);
    }

    // Search expenses by name, category, amount, or date
    public List<Expense> searchExpenses(String query) {
        String selection = COL_NAME + " LIKE ? OR " +
                COL_CATEGORY + " LIKE ? OR " +
                COL_AMOUNT + " LIKE ? OR " +
                COL_DATE + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};
        return getExpenses(selection, selectionArgs, null);
    }




    // Retrieve expenses with optional filters and ordering
    public List<Expense> getExpenses(String selection, String[] selectionArgs, String orderBy) {
        List<Expense> expenses = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, orderBy);
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME));
                    float amount = cursor.getFloat(cursor.getColumnIndexOrThrow(COL_AMOUNT));
                    String category = cursor.getString(cursor.getColumnIndexOrThrow(COL_CATEGORY));
                    String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_DATE));
                    expenses.add(new Expense(id, name, amount, category, date));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return expenses;
    }

    // Delete an expense by ID
    public boolean deleteExpense(int expenseId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_NAME, COL_ID + " = ?", new String[]{String.valueOf(expenseId)});
        db.close();
        return rowsAffected > 0;
    }

    // Clear all expenses
    public boolean clearAllExpenses() {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_NAME, null, null);
        db.close();
        return rowsDeleted > 0;
    }

    // Set the dark mode setting (0 for light, 1 for dark)
    public void setDarkMode(boolean isDarkMode) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DARK_MODE, isDarkMode ? 1 : 0);

        // Update or insert the dark mode setting
        int rowsUpdated = db.update(TABLE_SETTINGS, contentValues, null, null);
        if (rowsUpdated == 0) {
            db.insert(TABLE_SETTINGS, null, contentValues);
        }

        db.close();
    }

    // Get the current dark mode setting (returns true if dark mode is enabled)
    public boolean isDarkModeEnabled() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        boolean isDarkMode = false;
        try {
            cursor = db.rawQuery("SELECT " + COL_DARK_MODE + " FROM " + TABLE_SETTINGS, null);
            if (cursor != null && cursor.moveToFirst()) {
                isDarkMode = cursor.getInt(cursor.getColumnIndexOrThrow(COL_DARK_MODE)) == 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) cursor.close();
            db.close();
        }
        return isDarkMode;
    }
}
