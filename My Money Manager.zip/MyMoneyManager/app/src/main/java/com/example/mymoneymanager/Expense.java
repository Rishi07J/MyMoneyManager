package com.example.mymoneymanager;

public class Expense {
    private int id;
    private String name;
    private float amount;
    private String category;
    private String date;  // Add date field

    // Updated constructor to include date
    public Expense(int id, String name, float amount, String category, String date) {
        this.id = id;
        this.name = name;
        this.amount = amount;
        this.category = category;
        this.date = date;  // Initialize date
    }

    // Getter and Setter methods for each field
    public int getId() {
        return id;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getAmount() {
        return amount;
    }



    public String getCategory() {
        return category;
    }



    public String getDate() {
        return date;  // Getter for date
    }


}
