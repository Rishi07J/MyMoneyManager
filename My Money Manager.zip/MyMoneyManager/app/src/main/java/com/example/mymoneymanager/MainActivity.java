package com.example.mymoneymanager;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.SearchView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AlertDialog;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import androidx.core.view.GravityCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FloatingActionButton addExpenseButton;
    private DatabaseHelper databaseHelper;
    private ExpenseAdapter expenseAdapter;
    private List<Expense> expenses;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ActionBarDrawerToggle drawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup the toolbar with the hamburger menu icon
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Initialize DrawerLayout and NavigationView for the sidebar
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        // Setup ActionBarDrawerToggle to manage the drawer open/close actions
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.drawer_open, R.string.drawer_close);
        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();

        // Setup the Navigation Drawer
        navigationView.setNavigationItemSelectedListener(menuItem -> {
            if (menuItem.getItemId() == R.id.dark_mode_toggle) {
                toggleDarkMode();
            } else if (menuItem.getItemId() == R.id.clear_all_expenses) {
                showClearAllConfirmationDialog();
            } else if (menuItem.getItemId() == R.id.about) {
                showAboutDialog();
            }

            drawerLayout.closeDrawer(GravityCompat.START); // Close drawer after an item is selected
            return true;
        });


        // Initialize RecyclerView and set layout manager
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Initialize FloatingActionButton and set onClickListener to open AddExpenseActivity
        addExpenseButton = findViewById(R.id.addExpenseButton);
        addExpenseButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, AddExpenseActivity.class);
            startActivity(intent);
        });

        // Setup the search functionality
        SearchView searchView = findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                loadExpenses(query); // Filter by query
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                loadExpenses(newText); // Filter by query as you type
                return false;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadExpenses("");
    }

    private void loadExpenses(String query) {
        // Retrieve expenses from the database, filtered if a query is provided
        if (query.isEmpty()) {
            expenses = databaseHelper.getAllExpenses();
        } else {
            expenses = databaseHelper.searchExpenses(query);
        }

        // Set up the adapter and attach it to RecyclerView
        expenseAdapter = new ExpenseAdapter(expenses);
        recyclerView.setAdapter(expenseAdapter);
    }

    private void toggleDarkMode() {
        // Toggle between dark and light mode
        boolean isDarkMode = databaseHelper.isDarkModeEnabled();
        databaseHelper.setDarkMode(!isDarkMode);

        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            Toast.makeText(this, "Switched to Light Mode", Toast.LENGTH_SHORT).show();
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            Toast.makeText(this, "Switched to Dark Mode", Toast.LENGTH_SHORT).show();
        }
    }

    private void showClearAllConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Clear All Expenses")
                .setMessage("Are you sure you want to delete all expenses?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    boolean success = databaseHelper.clearAllExpenses();
                    if (success) {
                        loadExpenses(""); // Refresh the list
                        Toast.makeText(this, "All expenses deleted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to delete expenses", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", null)
                .create()
                .show();
    }

    private void showAboutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("About the App")
                .setMessage("We made this app for our Mobile App Development final project in college, but hey, it’s here for you all to use too!\n\nBuilt with care by Rishi, Suman, and Mayank—hope you find it helpful!")
                .setPositiveButton("OK", null)
                .create()
                .show();
    }


    // Synchronize the state of the drawer toggle when the activity is restored
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    // Handle configuration changes (e.g., orientation changes)
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }
}
