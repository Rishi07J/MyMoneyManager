package com.example.mymoneymanager;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {
    private EditText expenseNameInput, expenseAmountInput, expenseDateInput;
    private Spinner expenseCategorySpinner;
    private Button saveExpenseButton;
    private DatabaseHelper databaseHelper;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        expenseNameInput = findViewById(R.id.expenseNameInput);
        expenseAmountInput = findViewById(R.id.expenseAmountInput);
        expenseCategorySpinner = findViewById(R.id.expenseCategorySpinner);
        expenseDateInput = findViewById(R.id.expenseDateInput); // For date input
        saveExpenseButton = findViewById(R.id.saveExpenseButton);

        // Load categories into spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.expense_categories, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        expenseCategorySpinner.setAdapter(adapter);

        databaseHelper = new DatabaseHelper(this);

        // Set the current date by default in the EditText
        final Calendar calendar = Calendar.getInstance();
        final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedDate = dateFormat.format(calendar.getTime());
        expenseDateInput.setText(selectedDate);

        // Set click listener for the date input
        expenseDateInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open DatePicker dialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(AddExpenseActivity.this,
                        (view, year, month, dayOfMonth) -> {
                            // Format and update selected date
                            calendar.set(year, month, dayOfMonth);
                            selectedDate = dateFormat.format(calendar.getTime());
                            expenseDateInput.setText(selectedDate);
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });

        // Set click listener for the save button
        saveExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = expenseNameInput.getText().toString().trim();
                String amount = expenseAmountInput.getText().toString().trim();
                String category = expenseCategorySpinner.getSelectedItem().toString();

                if (!name.isEmpty() && !amount.isEmpty()) {
                    // Convert amount to a float or int
                    float expenseAmount = Float.parseFloat(amount);

                    // Insert into database
                    boolean insertSuccess = databaseHelper.insertExpense(name, expenseAmount, category, selectedDate);

                    if (insertSuccess) {
                        Toast.makeText(AddExpenseActivity.this, "Expense saved!", Toast.LENGTH_SHORT).show();
                        finish();  // Return to MainActivity
                    } else {
                        Toast.makeText(AddExpenseActivity.this, "Error saving expense", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(AddExpenseActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
