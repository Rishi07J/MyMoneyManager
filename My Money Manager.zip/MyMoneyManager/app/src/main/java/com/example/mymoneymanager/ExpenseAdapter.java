package com.example.mymoneymanager;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {
    private List<Expense> expenses;
    private Context context;
    private DatabaseHelper databaseHelper;

    public ExpenseAdapter(List<Expense> expenses) {
        this.expenses = expenses;
    }

    @Override
    public ExpenseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        context = parent.getContext();
        databaseHelper = new DatabaseHelper(context);
        View view = LayoutInflater.from(context).inflate(R.layout.item_expense, parent, false);
        return new ExpenseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        Expense expense = expenses.get(position);
        holder.nameTextView.setText(expense.getName());
        holder.amountTextView.setText(String.valueOf(expense.getAmount()));
        holder.categoryTextView.setText(expense.getCategory());
        holder.dateTextView.setText(expense.getDate()); // Bind the date to the TextView

        // Long press listener for editing or deleting an expense
        holder.itemView.setOnLongClickListener(v -> {
            showEditOrDeleteDialog(expense);
            return true; // Return true to indicate the event is handled
        });
    }

    @Override
    public int getItemCount() {
        return expenses.size();
    }

    private void showEditOrDeleteDialog(Expense expense) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("")
                .setItems(new String[] {"Delete"}, (dialog, which) -> {
                    if (which == 0) {
                        // Handle delete
                        deleteExpense(expense.getId());
                    }
                })
                .show();
    }

    private void deleteExpense(int expenseId) {
        boolean isDeleted = databaseHelper.deleteExpense(expenseId);
        if (isDeleted) {
            Toast.makeText(context, "Expense deleted", Toast.LENGTH_SHORT).show();
            // Refresh RecyclerView
            expenses.removeIf(expense -> expense.getId() == expenseId);
            notifyDataSetChanged();
        } else {
            Toast.makeText(context, "Failed to delete expense", Toast.LENGTH_SHORT).show();
        }
    }

    public static class ExpenseViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView amountTextView;
        TextView categoryTextView;
        TextView dateTextView; // New TextView for displaying the date

        public ExpenseViewHolder(View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.expenseName);
            amountTextView = itemView.findViewById(R.id.expenseAmount);
            categoryTextView = itemView.findViewById(R.id.expenseCategory);
            dateTextView = itemView.findViewById(R.id.expenseDate); // Initialize date TextView
        }
    }
}
